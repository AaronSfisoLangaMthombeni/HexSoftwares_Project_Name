import java.util.ArrayList;
import java.util.Scanner;

// Class representing a student
class Student {
    private String name;
    private String studentId;
    private double[] grades;

    public Student(String name, String studentId, double[] grades) {
        this.name = name;
        this.studentId = studentId;
        this.grades = grades;
    }

    public String getName() {
        return name;
    }

    public String getStudentId() {
        return studentId;
    }

    public double[] getGrades() {
        return grades;
    }

    public double calculateAverage() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        return grades.length > 0 ? sum / grades.length : 0;
    }

    public void displayGrades() {
        System.out.println("Grades for " + name + " (" + studentId + "):");
        for (double grade : grades) {
            System.out.println(grade);
        }
    }

    public boolean hasPassed(double passingGrade) {
        return calculateAverage() >= passingGrade;
    }
}

public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        System.out.print("Enter the number of students: ");
        int numberOfStudents = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("\nEnter details for student " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Student ID: ");
            String studentId = scanner.nextLine();

            System.out.print("Enter the number of grades: ");
            int numberOfGrades = scanner.nextInt();
            double[] grades = new double[numberOfGrades];

            for (int j = 0; j < numberOfGrades; j++) {
                System.out.print("Enter grade " + (j + 1) + ": ");
                grades[j] = scanner.nextDouble();
            }
            scanner.nextLine(); // Consume newline

            students.add(new Student(name, studentId, grades));
        }

        System.out.print("\nEnter the passing grade: ");
        double passingGrade = scanner.nextDouble();

        double classSum = 0;
        for (Student student : students) {
            System.out.println("\n---");
            student.displayGrades();
            double average = student.calculateAverage();
            System.out.println("Average Grade: " + average);
            System.out.println("Status: " + (student.hasPassed(passingGrade) ? "Passed" : "Failed"));
            classSum += average;
        }

        double classAverage = students.size() > 0 ? classSum / students.size() : 0;
        System.out.println("\nClass Average Grade: " + classAverage);

        scanner.close();
    }
}
