import java.util.Scanner;
 // Class representing a bank account
    class BankAccount {
        private double balance;
        private String accountNumber;

        public BankAccount(String accountNumber, double initialBalance) {
            this.accountNumber = accountNumber;
            if (initialBalance >= 0) {
                this.balance = initialBalance;
            } else {
                System.out.println("Initial balance cannot be negative. Setting balance to 0.");
                this.balance = 0;
            }
        }

        public String getAccountNumber() {
            return accountNumber;
        }

        public double getBalance() {
            return balance;
        }

        public void deposit(double amount) {
            if (amount > 0) {
                balance += amount;
                System.out.println("Deposited: " + amount);
            } else {
                System.out.println("Deposit amount must be positive.");
            }
        }

        public void withdraw(double amount) {
            if (amount > 0) {
                if (amount <= balance) {
                    balance -= amount;
                    System.out.println("Withdrawn: " + amount);
                } else {
                    System.out.println("Insufficient balance. Withdrawal failed.");
                }
            } else {
                System.out.println("Withdrawal amount must be positive.");
            }
        }
    }

    // Class representing a customer
    class Customer {
        private String name;
        private BankAccount account;

        public Customer(String name, BankAccount account) {
            this.name = name;
            this.account = account;
        }

        public String getName() {
            return name;
        }

        public BankAccount getAccount() {
            return account;
        }
    }

    public class BankingSystem {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Create a new account and customer
            System.out.println("Enter your name:");
            String name = scanner.nextLine();
            System.out.println("Enter initial deposit amount:");
            double initialDeposit = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            System.out.println("Enter account number:");
            String accountNumber = scanner.nextLine();

            BankAccount account = new BankAccount(accountNumber, initialDeposit);
            Customer customer = new Customer(name, account);

            System.out.println("Account created successfully for " + customer.getName());

            // Menu-driven banking system
            boolean exit = false;
            while (!exit) {
                System.out.println("\n--- Banking System Menu ---");
                System.out.println("1. Check Balance");
                System.out.println("2. Deposit Money");
                System.out.println("3. Withdraw Money");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Current Balance: " + account.getBalance());
                        break;
                    case 2:
                        System.out.println("Enter amount to deposit:");
                        double depositAmount = scanner.nextDouble();
                        account.deposit(depositAmount);
                        break;
                    case 3:
                        System.out.println("Enter amount to withdraw:");
                        double withdrawAmount = scanner.nextDouble();
                        account.withdraw(withdrawAmount);
                        break;
                    case 4:
                        System.out.println("Thank you for using our banking system. Goodbye!");
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

            scanner.close();
        }
    }