import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Movie {
    private String title;
    private String director;
    private int releaseYear;
    private String genre;

    public Movie(String title, String director, int releaseYear, String genre) {
        this.title = title;
        this.director = director;
        this.releaseYear = releaseYear;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Director: " + director + ", Year: " + releaseYear + ", Genre: " + genre;
    }
}

public class MovieDatabase {

    private List<Movie> movies;

    public MovieDatabase() {
        this.movies = new ArrayList<>();
    }

    public void addMovie(String title, String director, int releaseYear, String genre) {
        movies.add(new Movie(title, director, releaseYear, genre));
        System.out.println("Movie added successfully!");
    }

    public void searchMovies(String keyword) {
        System.out.println("\n--- Search Results ---");
        boolean found = false;
        for (Movie movie : movies) {
            if (movie.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                    movie.getDirector().toLowerCase().contains(keyword.toLowerCase()) ||
                    movie.getGenre().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(movie);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No movies found matching the keyword.");
        }
    }

    public void displayAllMovies() {
        System.out.println("\n--- Movie List ---");
        if (movies.isEmpty()) {
            System.out.println("No movies in the database.");
        } else {
            for (Movie movie : movies) {
                System.out.println(movie);
            }
        }
    }

    public static void main(String[] args) {
        MovieDatabase movieDatabase = new MovieDatabase();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Movie Database ---");
            System.out.println("1. Add New Movie");
            System.out.println("2. Search Movies");
            System.out.println("3. Display All Movies");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Movie Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Director: ");
                    String director = scanner.nextLine();
                    System.out.print("Enter Release Year: ");
                    int releaseYear = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Genre: ");
                    String genre = scanner.nextLine();
                    movieDatabase.addMovie(title, director, releaseYear, genre);
                    break;

                case 2:
                    System.out.print("Enter keyword to search: ");
                    String keyword = scanner.nextLine();
                    movieDatabase.searchMovies(keyword);
                    break;

                case 3:
                    movieDatabase.displayAllMovies();
                    break;

                case 4:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 4);

        scanner.close();
    }
}
