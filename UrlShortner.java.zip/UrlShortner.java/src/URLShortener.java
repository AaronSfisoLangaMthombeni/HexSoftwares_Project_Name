import java.util.HashMap;
import java.util.Scanner;

 public class URLShortener {

    private static final String BASE_URL = "http://short.ly/";
    private static HashMap<String, String> urlMap = new HashMap<>();
    private static int idCounter = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- URL Shortener ---");
            System.out.println("1. Shorten URL");
            System.out.println("2. Redirect URL");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter the long URL: ");
                    String longUrl = scanner.nextLine();
                    String shortUrl = shortenURL(longUrl);
                    System.out.println("Shortened URL: " + shortUrl);
                    break;

                case 2:
                    System.out.print("Enter the short URL: ");
                    String shortUrlInput = scanner.nextLine();
                    String originalUrl = redirectURL(shortUrlInput);
                    if (originalUrl != null) {
                        System.out.println("Original URL: " + originalUrl);
                    } else {
                        System.out.println("Short URL not found.");
                    }
                    break;

                case 3:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 3);

        scanner.close();
    }

    private static String shortenURL(String longUrl) {
        String shortUrl = BASE_URL + idCounter;
        urlMap.put(shortUrl, longUrl);
        idCounter++;
        return shortUrl;
    }

    private static String redirectURL(String shortUrl) {
        return urlMap.get(shortUrl);
    }
}
