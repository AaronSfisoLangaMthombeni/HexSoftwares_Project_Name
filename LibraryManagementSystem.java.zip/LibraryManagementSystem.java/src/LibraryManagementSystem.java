import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// Class showing a book
class Book {
    private String title;
    private String author;
    private String isbn;
    private boolean isIssued;

    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isIssued = false;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public boolean isIssued() {
        return isIssued;
    }

    public void setIssued(boolean issued) {
        isIssued = issued;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Issued: " + isIssued;
    }
}

// Class showing member
class Member {
    private String name;
    private String memberId;

    public Member(String name, String memberId) {
        this.name = name;
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public String getMemberId() {
        return memberId;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Member ID: " + memberId;
    }
}

// Class showing the library
class Library {
    private ArrayList<Book> books;
    private HashMap<String, String> issuedBooks; // maps isbn to memebr ID

    public Library() {
        this.books = new ArrayList<>();
        this.issuedBooks = new HashMap<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book);
    }

    public void issueBook(String isbn, Member member) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                if (!book.isIssued()) {
                    book.setIssued(true);
                    issuedBooks.put(isbn, member.getMemberId());
                    System.out.println("Book issued to " + member.getName());
                } else {
                    System.out.println("Book is already issued.");
                }
                return;
            }
        }
        System.out.println("Book with ISBN " + isbn + " not found.");
    }

    public void returnBook(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                if (book.isIssued()) {
                    book.setIssued(false);
                    issuedBooks.remove(isbn);
                    System.out.println("Book returned: " + book.getTitle());
                } else {
                    System.out.println("Book is not issued.");
                }
                return;
            }
        }
        System.out.println("Book with ISBN " + isbn + " not found.");
    }

    public void listBooks() {
        System.out.println("\nBooks in the library:");
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public void listIssuedBooks() {
        System.out.println("\nIssued Books:");
        for (String isbn : issuedBooks.keySet()) {
            System.out.println("ISBN: " + isbn + ", Issued to Member ID: " + issuedBooks.get(isbn));
        }
    }
}

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Library Management System Menu ---");
            System.out.println("1. Add Book");
            System.out.println("2. Issue Book");
            System.out.println("3. Return Book");
            System.out.println("4. List All Books");
            System.out.println("5. List Issued Books");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter book title:");
                    String title = scanner.nextLine();
                    System.out.println("Enter book author:");
                    String author = scanner.nextLine();
                    System.out.println("Enter book ISBN:");
                    String isbn = scanner.nextLine();
                    library.addBook(new Book(title, author, isbn));
                    break;
                case 2:
                    System.out.println("Enter ISBN of the book to issue:");
                    String issueIsbn = scanner.nextLine();
                    System.out.println("Enter member name:");
                    String memberName = scanner.nextLine();
                    System.out.println("Enter member ID:");
                    String memberId = scanner.nextLine();
                    library.issueBook(issueIsbn, new Member(memberName, memberId));
                    break;
                case 3:
                    System.out.println("Enter ISBN of the book to return:");
                    String returnIsbn = scanner.nextLine();
                    library.returnBook(returnIsbn);
                    break;
                case 4:
                    library.listBooks();
                    break;
                case 5:
                    library.listIssuedBooks();
                    break;
                case 6:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
